package com.botmod.bot;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Hashtable;
import java.util.UUID;
import java.util.zip.DataFormatException;
import java.util.zip.Deflater;
import java.util.zip.Inflater;

import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;

/**
 * Lekki klient Minecrafta 1.21.4 (protokół 769) - loguje się offline (bez konta premium),
 * przechodzi konfigurację i zostaje w grze (keep-alive). Nie renderuje nic.
 *
 * ID pakietów dla 1.21.4 są zebrane w stałych poniżej.
 */
public class MinecraftBot implements Runnable {
    public static final String HOST = "anarchia.gg";
    public static final int DEFAULT_PORT = 25565;
    private static final int PROTOCOL = 769;

    // --- LOGIN ---
    private static final int L_S_LOGIN_START = 0x00;
    private static final int L_S_PLUGIN_RESPONSE = 0x02;
    private static final int L_S_LOGIN_ACK = 0x03;
    private static final int L_S_COOKIE_RESPONSE = 0x04;
    private static final int L_C_DISCONNECT = 0x00;
    private static final int L_C_ENCRYPTION = 0x01;
    private static final int L_C_SUCCESS = 0x02;
    private static final int L_C_COMPRESSION = 0x03;
    private static final int L_C_PLUGIN_REQUEST = 0x04;
    private static final int L_C_COOKIE_REQUEST = 0x05;

    // --- CONFIG ---
    private static final int C_S_CLIENT_INFO = 0x00;
    private static final int C_S_COOKIE_RESPONSE = 0x01;
    private static final int C_S_FINISH = 0x03;
    private static final int C_S_KEEP_ALIVE = 0x04;
    private static final int C_S_PONG = 0x05;
    private static final int C_S_RESOURCE_PACK = 0x06;
    private static final int C_S_KNOWN_PACKS = 0x07;
    private static final int C_C_COOKIE_REQUEST = 0x00;
    private static final int C_C_DISCONNECT = 0x02;
    private static final int C_C_FINISH = 0x03;
    private static final int C_C_KEEP_ALIVE = 0x04;
    private static final int C_C_PING = 0x05;
    private static final int C_C_ADD_RESOURCE_PACK = 0x09;
    private static final int C_C_TRANSFER = 0x0B;
    private static final int C_C_KNOWN_PACKS = 0x0E;

    // --- PLAY ---
    private static final int P_S_CONFIRM_TELEPORT = 0x00;
    private static final int P_S_CHAT_COMMAND = 0x05;
    private static final int P_S_CHAT_MESSAGE = 0x07;
    private static final int P_S_ACK_CONFIGURATION = 0x0E;
    private static final int P_S_KEEP_ALIVE = 0x1A;
    private static final int P_C_DISCONNECT = 0x1D;
    private static final int P_C_KEEP_ALIVE = 0x27;
    private static final int P_C_SYNC_POSITION = 0x42;
    private static final int P_C_START_CONFIGURATION = 0x70;
    private static final int P_C_SYSTEM_CHAT = 0x73;

    private enum State { LOGIN, CONFIG, PLAY }

    @FunctionalInterface
    private interface Writer {
        void write(DataOutputStream o) throws IOException;
    }

    private final String nick;
    private final Object writeLock = new Object();
    private volatile boolean running;
    private volatile State state = State.LOGIN;
    private volatile int threshold = -1;
    private Socket socket;
    private DataInputStream in;
    private OutputStream out;

    public MinecraftBot(String nick) {
        this.nick = nick;
    }

    public void start() {
        running = true;
        Thread t = new Thread(this, "botmod-" + nick);
        t.setDaemon(true);
        t.start();
    }

    public void stop() {
        running = false;
        closeSocket();
    }

    public boolean isRunning() {
        return running;
    }

    @Override
    public void run() {
        try {
            InetSocketAddress address = resolve();
            BotConsole.log("Łączę z " + HOST + " (" + address.getHostString() + ":" + address.getPort() + ") jako " + nick + "...");
            socket = new Socket();
            socket.connect(address, 10_000);
            socket.setTcpNoDelay(true);
            socket.setSoTimeout(60_000);
            in = new DataInputStream(new BufferedInputStream(socket.getInputStream()));
            out = socket.getOutputStream();

            sendHandshake(address.getPort());
            sendLoginStart();

            while (running) {
                Buf packet = readPacket();
                try {
                    switch (state) {
                        case LOGIN -> handleLogin(packet);
                        case CONFIG -> handleConfig(packet);
                        case PLAY -> handlePlay(packet);
                    }
                } catch (IOException e) {
                    throw e;
                } catch (RuntimeException e) {
                    BotConsole.log("Błąd przy pakiecie 0x" + Integer.toHexString(packet.id) + " (" + state + "): " + e);
                }
            }
        } catch (EOFException e) {
            if (running) {
                BotConsole.log("Serwer zamknął połączenie.");
            }
        } catch (IOException e) {
            if (running) {
                BotConsole.log("Błąd połączenia: " + e);
            }
        } finally {
            running = false;
            closeSocket();
            BotConsole.log("Bot rozłączony.");
        }
    }

    // ------------------------------------------------------------------ handlers

    private void handleLogin(Buf b) throws IOException {
        switch (b.id) {
            case L_C_DISCONNECT -> {
                BotConsole.log("Serwer odrzucił logowanie: " + Buf.fromJson(b.readString()));
                running = false;
            }
            case L_C_ENCRYPTION -> {
                BotConsole.log("Serwer wymaga konta premium (online-mode) - bot offline nie wejdzie.");
                running = false;
            }
            case L_C_SUCCESS -> {
                BotConsole.log("Zalogowano jako " + nick + ". Konfiguracja...");
                send(L_S_LOGIN_ACK, null);
                state = State.CONFIG;
                send(C_S_CLIENT_INFO, o -> {
                    writeString(o, "pl_PL");
                    o.writeByte(8);          // view distance
                    writeVarInt(o, 0);       // chat mode: enabled
                    o.writeBoolean(true);    // chat colors
                    o.writeByte(0x7F);       // skin parts
                    writeVarInt(o, 1);       // main hand: right
                    o.writeBoolean(false);   // text filtering
                    o.writeBoolean(true);    // allow server listings
                    writeVarInt(o, 0);       // particles: all
                });
            }
            case L_C_COMPRESSION -> threshold = b.readVarInt();
            case L_C_PLUGIN_REQUEST -> {
                int messageId = b.readVarInt();
                send(L_S_PLUGIN_RESPONSE, o -> {
                    writeVarInt(o, messageId);
                    o.writeBoolean(false);
                });
            }
            case L_C_COOKIE_REQUEST -> {
                String key = b.readString();
                send(L_S_COOKIE_RESPONSE, o -> {
                    writeString(o, key);
                    o.writeBoolean(false);
                });
            }
            default -> { }
        }
    }

    private void handleConfig(Buf b) throws IOException {
        switch (b.id) {
            case C_C_COOKIE_REQUEST -> {
                String key = b.readString();
                send(C_S_COOKIE_RESPONSE, o -> {
                    writeString(o, key);
                    o.writeBoolean(false);
                });
            }
            case C_C_DISCONNECT -> {
                BotConsole.log("Rozłączono (konfiguracja): " + b.readNbtText());
                running = false;
            }
            case C_C_FINISH -> {
                send(C_S_FINISH, null);
                state = State.PLAY;
                BotConsole.log("Bot wszedł do gry na " + HOST + ".");
            }
            case C_C_KEEP_ALIVE -> {
                long id = b.readLong();
                send(C_S_KEEP_ALIVE, o -> o.writeLong(id));
            }
            case C_C_PING -> {
                int id = b.readInt();
                send(C_S_PONG, o -> o.writeInt(id));
            }
            case C_C_ADD_RESOURCE_PACK -> {
                long hi = b.readLong();
                long lo = b.readLong();
                BotConsole.log("Serwer wysłał resource pack - akceptuję.");
                for (int result : new int[] {3, 4, 0}) { // accepted, downloaded, loaded
                    send(C_S_RESOURCE_PACK, o -> {
                        o.writeLong(hi);
                        o.writeLong(lo);
                        writeVarInt(o, result);
                    });
                }
            }
            case C_C_TRANSFER -> BotConsole.log("Serwer chce przenieść bota na inny adres (transfer) - ignoruję.");
            case C_C_KNOWN_PACKS -> send(C_S_KNOWN_PACKS, o -> writeVarInt(o, 0));
            default -> { }
        }
    }

    private void handlePlay(Buf b) throws IOException {
        switch (b.id) {
            case P_C_KEEP_ALIVE -> {
                long id = b.readLong();
                send(P_S_KEEP_ALIVE, o -> o.writeLong(id));
            }
            case P_C_DISCONNECT -> {
                BotConsole.log("Wyrzucono z serwera: " + b.readNbtText());
                running = false;
            }
            case P_C_SYSTEM_CHAT -> {
                String text = b.readNbtText();
                boolean overlay = b.readBoolean();
                if (!overlay && !text.isBlank()) {
                    BotConsole.log(text);
                }
            }
            case P_C_START_CONFIGURATION -> {
                send(P_S_ACK_CONFIGURATION, null);
                state = State.CONFIG;
                BotConsole.log("Serwer przełączył bota w fazę konfiguracji.");
            }
            case P_C_SYNC_POSITION -> {
                int teleportId = b.readVarInt();
                send(P_S_CONFIRM_TELEPORT, o -> writeVarInt(o, teleportId));
            }
            default -> { }
        }
    }

    // ------------------------------------------------------------------ chat

    /** Tekst zaczynający się od "/" idzie jako komenda, reszta jako zwykły czat. */
    public void sendChat(String text) {
        if (!running || state != State.PLAY) {
            BotConsole.log("Bot nie jest jeszcze w grze.");
            return;
        }
        try {
            if (text.startsWith("/")) {
                String command = text.substring(1);
                send(P_S_CHAT_COMMAND, o -> writeString(o, command));
            } else {
                send(P_S_CHAT_MESSAGE, o -> {
                    writeString(o, text);
                    o.writeLong(System.currentTimeMillis());
                    o.writeLong(0L);          // salt
                    o.writeBoolean(false);    // brak podpisu
                    writeVarInt(o, 0);        // message count
                    o.write(new byte[3]);     // acknowledged (20 bitów)
                });
            }
            BotConsole.log("> " + text);
        } catch (IOException e) {
            BotConsole.log("Nie udało się wysłać: " + e);
        }
    }

    // ------------------------------------------------------------------ network

    private InetSocketAddress resolve() {
        try {
            Hashtable<String, String> env = new Hashtable<>();
            env.put("java.naming.factory.initial", "com.sun.jndi.dns.DnsContextFactory");
            env.put("java.naming.provider.url", "dns:");
            DirContext ctx = new InitialDirContext(env);
            Attributes attrs = ctx.getAttributes("_minecraft._tcp." + HOST, new String[] {"SRV"});
            Attribute srv = attrs.get("srv");
            if (srv != null && srv.size() > 0) {
                String[] parts = srv.get(0).toString().split(" ");
                int port = Integer.parseInt(parts[2]);
                String host = parts[3];
                if (host.endsWith(".")) {
                    host = host.substring(0, host.length() - 1);
                }
                return new InetSocketAddress(host, port);
            }
        } catch (Throwable ignored) {
            // brak rekordu SRV - używamy domyślnego portu
        }
        return new InetSocketAddress(HOST, DEFAULT_PORT);
    }

    private void sendHandshake(int port) throws IOException {
        send(0x00, o -> {
            writeVarInt(o, PROTOCOL);
            writeString(o, HOST);
            o.writeShort(port);
            writeVarInt(o, 2); // next state: login
        });
    }

    private void sendLoginStart() throws IOException {
        UUID uuid = UUID.nameUUIDFromBytes(("OfflinePlayer:" + nick).getBytes(StandardCharsets.UTF_8));
        send(L_S_LOGIN_START, o -> {
            writeString(o, nick);
            o.writeLong(uuid.getMostSignificantBits());
            o.writeLong(uuid.getLeastSignificantBits());
        });
    }

    private Buf readPacket() throws IOException {
        int length = readVarInt(in);
        if (length < 0 || length > (1 << 23)) {
            throw new IOException("Zła długość pakietu: " + length);
        }
        byte[] data = new byte[length];
        in.readFully(data);
        Buf b = new Buf(data);
        if (threshold >= 0) {
            int dataLength = b.readVarInt();
            if (dataLength != 0) {
                Inflater inflater = new Inflater();
                inflater.setInput(data, b.pos, data.length - b.pos);
                byte[] unpacked = new byte[dataLength];
                try {
                    int n = 0;
                    while (n < dataLength) {
                        int r = inflater.inflate(unpacked, n, dataLength - n);
                        if (r == 0 && (inflater.finished() || inflater.needsInput())) {
                            break;
                        }
                        n += r;
                    }
                } catch (DataFormatException e) {
                    throw new IOException(e);
                } finally {
                    inflater.end();
                }
                b = new Buf(unpacked);
            }
        }
        b.id = b.readVarInt();
        return b;
    }

    private void send(int id, Writer writer) throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        DataOutputStream body = new DataOutputStream(bytes);
        writeVarInt(body, id);
        if (writer != null) {
            writer.write(body);
        }
        byte[] packet = bytes.toByteArray();

        ByteArrayOutputStream frameBytes = new ByteArrayOutputStream();
        DataOutputStream frame = new DataOutputStream(frameBytes);
        int th = threshold;
        if (th < 0) {
            writeVarInt(frame, packet.length);
            frame.write(packet);
        } else {
            ByteArrayOutputStream innerBytes = new ByteArrayOutputStream();
            DataOutputStream inner = new DataOutputStream(innerBytes);
            if (packet.length >= th) {
                writeVarInt(inner, packet.length);
                inner.write(deflate(packet));
            } else {
                writeVarInt(inner, 0);
                inner.write(packet);
            }
            writeVarInt(frame, innerBytes.size());
            frame.write(innerBytes.toByteArray());
        }
        synchronized (writeLock) {
            out.write(frameBytes.toByteArray());
            out.flush();
        }
    }

    private static byte[] deflate(byte[] data) {
        Deflater deflater = new Deflater();
        deflater.setInput(data);
        deflater.finish();
        ByteArrayOutputStream result = new ByteArrayOutputStream();
        byte[] buffer = new byte[4096];
        while (!deflater.finished()) {
            int n = deflater.deflate(buffer);
            result.write(buffer, 0, n);
        }
        deflater.end();
        return result.toByteArray();
    }

    private void closeSocket() {
        try {
            if (socket != null) {
                socket.close();
            }
        } catch (IOException ignored) {
            // nic
        }
    }

    private static int readVarInt(DataInputStream in) throws IOException {
        int value = 0;
        int shift = 0;
        while (true) {
            int b = in.readUnsignedByte();
            value |= (b & 0x7F) << shift;
            if ((b & 0x80) == 0) {
                return value;
            }
            shift += 7;
            if (shift > 35) {
                throw new IOException("VarInt za duży");
            }
        }
    }

    private static void writeVarInt(DataOutputStream o, int value) throws IOException {
        while ((value & ~0x7F) != 0) {
            o.writeByte((value & 0x7F) | 0x80);
            value >>>= 7;
        }
        o.writeByte(value);
    }

    private static void writeString(DataOutputStream o, String s) throws IOException {
        byte[] bytes = s.getBytes(StandardCharsets.UTF_8);
        writeVarInt(o, bytes.length);
        o.write(bytes);
    }
}
