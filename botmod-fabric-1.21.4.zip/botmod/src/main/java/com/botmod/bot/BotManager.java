package com.botmod.bot;

/** Trzyma aktualnie uruchomionego bota. */
public final class BotManager {
    private static MinecraftBot bot;

    private BotManager() {}

    public static synchronized boolean isRunning() {
        return bot != null && bot.isRunning();
    }

    public static synchronized void start(String nick) {
        if (isRunning()) {
            BotConsole.log("Bot już działa.");
            return;
        }
        bot = new MinecraftBot(nick);
        bot.start();
    }

    public static synchronized void stop() {
        if (bot != null) {
            bot.stop();
        }
    }

    public static synchronized void send(String text) {
        if (bot == null || !bot.isRunning()) {
            BotConsole.log("Bot nie jest uruchomiony.");
            return;
        }
        bot.sendChat(text);
    }
}
