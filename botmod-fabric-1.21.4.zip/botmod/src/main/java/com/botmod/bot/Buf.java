package com.botmod.bot;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Czytnik pakietu + dekodowanie tekstów (NBT z sieci i JSON). */
final class Buf {
    final byte[] d;
    int pos;
    int id;

    Buf(byte[] d) {
        this.d = d;
    }

    int readUByte() {
        return d[pos++] & 0xFF;
    }

    int readUShort() {
        int v = ((d[pos] & 0xFF) << 8) | (d[pos + 1] & 0xFF);
        pos += 2;
        return v;
    }

    int readShort() {
        return (short) readUShort();
    }

    int readInt() {
        int v = ((d[pos] & 0xFF) << 24) | ((d[pos + 1] & 0xFF) << 16) | ((d[pos + 2] & 0xFF) << 8) | (d[pos + 3] & 0xFF);
        pos += 4;
        return v;
    }

    long readLong() {
        long hi = readInt() & 0xFFFFFFFFL;
        long lo = readInt() & 0xFFFFFFFFL;
        return (hi << 32) | lo;
    }

    boolean readBoolean() {
        return d[pos++] != 0;
    }

    int readVarInt() {
        int value = 0;
        int shift = 0;
        while (true) {
            int b = readUByte();
            value |= (b & 0x7F) << shift;
            if ((b & 0x80) == 0) {
                return value;
            }
            shift += 7;
            if (shift > 35) {
                throw new RuntimeException("VarInt za duży");
            }
        }
    }

    String readString() {
        int len = readVarInt();
        String s = new String(d, pos, len, StandardCharsets.UTF_8);
        pos += len;
        return s;
    }

    // ---------- NBT (format sieciowy 1.20.2+: korzeń bez nazwy) ----------

    /** Czyta tekst (komponent) zapisany jako NBT i zwraca zwykły tekst. */
    String readNbtText() {
        int type = readUByte();
        if (type == 0) {
            return "";
        }
        return strip(flatten(readTag(type)));
    }

    private Object readTag(int type) {
        switch (type) {
            case 1:
                return (int) d[pos++];
            case 2:
                return readShort();
            case 3:
                return readInt();
            case 4:
                return readLong();
            case 5:
                return Float.intBitsToFloat(readInt());
            case 6:
                return Double.longBitsToDouble(readLong());
            case 7: {
                int n = readInt();
                pos += n;
                return null;
            }
            case 8: {
                int n = readUShort();
                String s = new String(d, pos, n, StandardCharsets.UTF_8);
                pos += n;
                return s;
            }
            case 9: {
                int elemType = readUByte();
                int n = readInt();
                List<Object> list = new ArrayList<>();
                for (int i = 0; i < n; i++) {
                    list.add(readTag(elemType));
                }
                return list;
            }
            case 10: {
                Map<String, Object> map = new LinkedHashMap<>();
                while (true) {
                    int t = readUByte();
                    if (t == 0) {
                        break;
                    }
                    int n = readUShort();
                    String name = new String(d, pos, n, StandardCharsets.UTF_8);
                    pos += n;
                    map.put(name, readTag(t));
                }
                return map;
            }
            case 11: {
                int n = readInt();
                pos += 4 * n;
                return null;
            }
            case 12: {
                int n = readInt();
                pos += 8 * n;
                return null;
            }
            default:
                throw new RuntimeException("Nieznany typ NBT: " + type);
        }
    }

    @SuppressWarnings("unchecked")
    private static String flatten(Object o) {
        if (o == null) {
            return "";
        }
        if (o instanceof String s) {
            return s;
        }
        if (o instanceof List<?> list) {
            StringBuilder sb = new StringBuilder();
            for (Object e : list) {
                sb.append(flatten(e));
            }
            return sb.toString();
        }
        if (o instanceof Map<?, ?> raw) {
            Map<String, Object> m = (Map<String, Object>) raw;
            StringBuilder sb = new StringBuilder();
            if (m.containsKey("text")) {
                sb.append(flatten(m.get("text")));
            } else if (m.containsKey("translate")) {
                sb.append(flatten(m.get("translate")));
                Object with = m.get("with");
                if (with instanceof List<?> args && !args.isEmpty()) {
                    sb.append(" ");
                    boolean first = true;
                    for (Object a : args) {
                        if (!first) {
                            sb.append(", ");
                        }
                        sb.append(flatten(a));
                        first = false;
                    }
                }
            }
            if (m.containsKey("extra")) {
                sb.append(flatten(m.get("extra")));
            }
            return sb.toString();
        }
        return String.valueOf(o);
    }

    // ---------- JSON (rozłączenie w fazie logowania) ----------

    static String fromJson(String json) {
        try {
            return strip(flattenJson(JsonParser.parseString(json)));
        } catch (Exception e) {
            return strip(json);
        }
    }

    private static String flattenJson(JsonElement e) {
        if (e == null || e.isJsonNull()) {
            return "";
        }
        if (e.isJsonPrimitive()) {
            return e.getAsString();
        }
        if (e.isJsonArray()) {
            StringBuilder sb = new StringBuilder();
            JsonArray arr = e.getAsJsonArray();
            for (JsonElement el : arr) {
                sb.append(flattenJson(el));
            }
            return sb.toString();
        }
        JsonObject o = e.getAsJsonObject();
        StringBuilder sb = new StringBuilder();
        if (o.has("text")) {
            sb.append(flattenJson(o.get("text")));
        } else if (o.has("translate")) {
            sb.append(flattenJson(o.get("translate")));
            if (o.has("with") && o.get("with").isJsonArray()) {
                sb.append(" ");
                boolean first = true;
                for (JsonElement a : o.getAsJsonArray("with")) {
                    if (!first) {
                        sb.append(", ");
                    }
                    sb.append(flattenJson(a));
                    first = false;
                }
            }
        }
        if (o.has("extra")) {
            sb.append(flattenJson(o.get("extra")));
        }
        return sb.toString();
    }

    private static String strip(String s) {
        return s.replaceAll("§.", "");
    }
}
