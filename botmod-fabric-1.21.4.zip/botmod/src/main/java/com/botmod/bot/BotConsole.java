package com.botmod.bot;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/** Prosta konsola bota - bufor linii czytany przez GUI. */
public final class BotConsole {
    private static final List<String> LINES = new ArrayList<>();
    private static final DateTimeFormatter FORMAT = DateTimeFormatter.ofPattern("HH:mm:ss");
    private static final int MAX_LINES = 300;

    private BotConsole() {}

    public static synchronized void log(String message) {
        String time = LocalTime.now().format(FORMAT);
        for (String line : message.split("\\R")) {
            LINES.add("[" + time + "] " + line);
        }
        while (LINES.size() > MAX_LINES) {
            LINES.remove(0);
        }
    }

    public static synchronized List<String> snapshot() {
        return new ArrayList<>(LINES);
    }

    public static synchronized void clear() {
        LINES.clear();
    }
}
