package com.botmod;

import com.botmod.bot.BotConsole;
import com.botmod.bot.BotManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class BotScreen extends Screen {
    private static final Pattern NICK = Pattern.compile("^[A-Za-z0-9_]{3,16}$");
    private static String lastNick = "";

    private TextFieldWidget nickField;
    private TextFieldWidget inputField;
    private ButtonWidget toggleButton;

    private int boxX;
    private int boxY;
    private int boxW;
    private int boxH;
    private int scroll = 0; // ile linii od dołu

    public BotScreen() {
        super(Text.literal("Bot - anarchia.gg"));
    }

    @Override
    protected void init() {
        int w = Math.min(380, width - 20);
        int left = (width - w) / 2;

        nickField = new TextFieldWidget(textRenderer, left, 30, 140, 20, Text.literal("Nick"));
        nickField.setMaxLength(16);
        nickField.setPlaceholder(Text.literal("Nick bota"));
        nickField.setText(lastNick);
        addDrawableChild(nickField);

        toggleButton = ButtonWidget.builder(buttonLabel(), button -> toggle())
                .dimensions(left + 145, 30, 120, 20)
                .build();
        addDrawableChild(toggleButton);

        addDrawableChild(ButtonWidget.builder(Text.literal("Wyczyść"), button -> {
            BotConsole.clear();
            scroll = 0;
        }).dimensions(left + 270, 30, w - 270, 20).build());

        boxX = left;
        boxY = 58;
        boxW = w;
        boxH = height - 58 - 34;

        inputField = new TextFieldWidget(textRenderer, left, height - 26, w, 20, Text.literal("Czat"));
        inputField.setMaxLength(256);
        inputField.setPlaceholder(Text.literal("Czat / komenda bota (Enter wysyła, np. /register ...)"));
        addDrawableChild(inputField);

        setInitialFocus(nickField);
    }

    private Text buttonLabel() {
        return Text.literal(BotManager.isRunning() ? "Zatrzymaj bota" : "Wyślij bota");
    }

    private void toggle() {
        if (BotManager.isRunning()) {
            BotManager.stop();
            return;
        }
        String nick = nickField.getText().trim();
        if (!NICK.matcher(nick).matches()) {
            BotConsole.log("Zły nick - użyj 3-16 znaków: litery, cyfry, _");
            return;
        }
        lastNick = nick;
        BotManager.start(nick);
    }

    @Override
    public void tick() {
        super.tick();
        if (toggleButton != null) {
            toggleButton.setMessage(buttonLabel());
        }
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if ((keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) && inputField.isFocused()) {
            String text = inputField.getText().trim();
            if (!text.isEmpty()) {
                BotManager.send(text);
                inputField.setText("");
                scroll = 0;
            }
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        scroll += (int) Math.signum(verticalAmount) * 3;
        if (scroll < 0) {
            scroll = 0;
        }
        return true;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);

        context.drawCenteredTextWithShadow(textRenderer, Text.literal("Bot na anarchia.gg"), width / 2, 12, 0xFFFFFFFF);

        context.fill(boxX, boxY, boxX + boxW, boxY + boxH, 0xAA000000);

        List<OrderedText> lines = new ArrayList<>();
        for (String line : BotConsole.snapshot()) {
            lines.addAll(textRenderer.wrapLines(Text.literal(line), boxW - 8));
        }

        int lineHeight = 10;
        int visible = Math.max(1, (boxH - 6) / lineHeight);
        int maxScroll = Math.max(0, lines.size() - visible);
        if (scroll > maxScroll) {
            scroll = maxScroll;
        }
        int end = lines.size() - scroll;
        int start = Math.max(0, end - visible);

        int y = boxY + 4;
        for (int i = start; i < end; i++) {
            context.drawText(textRenderer, lines.get(i), boxX + 4, y, 0xFFE0E0E0, false);
            y += lineHeight;
        }
    }

    @Override
    public void removed() {
        lastNick = nickField.getText();
        super.removed();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
