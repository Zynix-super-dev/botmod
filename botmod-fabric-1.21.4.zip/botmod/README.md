# Bot Mod (Fabric 1.21.4)

Klawisz **X** otwiera GUI (w grze i w menu głównym):
- pole **Nick bota** + przycisk **Wyślij bota** (po uruchomieniu zmienia się w **Zatrzymaj bota**),
- **konsola bota** (przewijana kółkiem myszy, przycisk Wyczyść),
- pole na dole: tekst idzie jako czat bota, a zaczynający się od `/` jako komenda (np. `/register haslo haslo`).

Bot łączy się z `anarchia.gg` osobnym połączeniem (tryb offline, bez konta premium) i zostaje w grze.
Na razie robi tylko tyle - wchodzi na serwer i pokazuje w konsoli, co serwer do niego pisze.

## Budowanie
Wymagania: Java 21 + Minecraft 1.21.4 z Fabric Loaderem i Fabric API 0.119.4+1.21.4.

1. Otwórz folder w IntelliJ IDEA (File -> Open -> build.gradle -> Open as Project).
2. Po zaimportowaniu: Gradle -> Tasks -> build -> build (lub w terminalu `gradle build`).
3. Gotowy plik: `build/libs/botmod-1.0.0.jar` -> wrzuć do folderu `mods`.

Klawisz można zmienić w Opcje -> Sterowanie -> "Open bot GUI".
